#!/bin/sh
protoc --python_out=../ *.proto